from django.db import models

# Create your models here.
class Course(models.Model):
    teacher = models.CharField(max_length=500)
    c_name = models.CharField(max_length=500)
    c_id = models.CharField(max_length=500)
    c_type = models.CharField(max_length=500)
    c_format = models.CharField(max_length=500)
    home = models.CharField(max_length=500)
    exper = models.CharField(max_length=500)
    exam = models.CharField(max_length=500)
    attend = models.CharField(max_length=500)
    ass_type = models.CharField(max_length=500)
    c_intr = models.CharField(max_length=500)
    c_req = models.CharField(max_length=500)
    others = models.CharField(max_length=500)

    def __unicode__(self):
        return self.c_name