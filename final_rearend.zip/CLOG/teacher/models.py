from django.db import models

# Create your models here.
class User(models.Model):
    Email = models.CharField(max_length=500)
    Password = models.CharField(max_length=500)
    StudentID = models.CharField(max_length=500)
    password2 = models.CharField(max_length=500)
    Grade = models.CharField(max_length=500)
    newer = models.CharField(max_length=500)

    def __unicode__(self):
        return self.username