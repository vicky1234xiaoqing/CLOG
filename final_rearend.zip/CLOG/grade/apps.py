from django.apps import AppConfig


class GradeConfig(AppConfig):
    name = 'grade'
